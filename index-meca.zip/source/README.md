## Where do microplastics come from?

Classification models train using visual data of sea and river microplastics.